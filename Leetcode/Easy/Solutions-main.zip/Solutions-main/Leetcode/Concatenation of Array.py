class Solution:
    def getConcatenation(self, nums: List[int]) -> List[int]:
        nums = nums
        num2 = nums.copy()
        joined = nums + num2
        return joined
        
